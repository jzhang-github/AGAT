# -*- coding: utf-8 -*-
"""
Created on Tue Aug 15 11:41:20 2023

@author: ZHANG Jun
"""

__version__ = '7.12'

# import important object.
from .GatApp import GatApp, GatAseCalculator, GatCalculator
