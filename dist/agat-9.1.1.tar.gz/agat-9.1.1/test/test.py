# -*- coding: utf-8 -*-
"""
Created on Tue Oct  3 20:55:10 2023

@author: ZHANG Jun
"""

# test build graphs

# test train

# test application
